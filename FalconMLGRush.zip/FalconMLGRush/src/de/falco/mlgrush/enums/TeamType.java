package de.falco.mlgrush.enums;

// The project Stream - MLGRush is Edited By Falcon.
// This Plugin Made For ASRBW
//
//           

public enum TeamType {

    TEAM_1,
    TEAM_2,
    NONE

}
